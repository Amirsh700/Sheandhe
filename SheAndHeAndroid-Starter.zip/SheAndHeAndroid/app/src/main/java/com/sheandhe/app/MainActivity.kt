package com.sheandhe.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090914)
private val Panel = Color(0xFF15152A)
private val Panel2 = Color(0xFF1C1B35)
private val Pink = Color(0xFFFF3EAA)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)
private val Muted = Color(0xFFAAA8C4)
private val Neon = Brush.linearGradient(listOf(Color(0xFFFF4FB8), Color(0xFF8B5CF6), Color(0xFF22C9F6)))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 20)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 20)
        setContent { SheAndHeApp() }
    }
}

@Composable
fun SheAndHeApp() {
    var tab by remember { mutableStateOf("خانه") }
    var liked by remember { mutableStateOf(setOf<Int>()) }
    var showComposer by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Violet)) {
        Scaffold(containerColor = Night, bottomBar = { BottomBar(tab, onSelect = { if (it == "افزودن") showComposer = true else tab = it }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Night)) {
                TopHeader(tab)
                when (tab) {
                    "خانه" -> HomeScreen(liked, onLike = { id -> liked = if (id in liked) liked - id else liked + id })
                    "کشف" -> DiscoverScreen()
                    "پیام‌ها" -> MessagesScreen()
                    "کیف پول" -> WalletScreen()
                    "پروفایل" -> ProfileScreen()
                    else -> HomeScreen(liked, onLike = { id -> liked = if (id in liked) liked - id else liked + id })
                }
            }
            if (showComposer) AlertDialog(
                onDismissRequest = { showComposer = false },
                containerColor = Panel2,
                title = { Text("ساخت پست جدید", color = Color.White) },
                text = { Text("در نسخهٔ بعدی، افزودن عکس و ویدئو و انتشار آنلاین با حساب کاربری فعال می‌شود.", color = Muted) },
                confirmButton = { TextButton2("متوجه شدم") { showComposer = false } }
            )
        }
    }
}

@Composable fun TopHeader(tab: String) {
    Row(Modifier.fillMaxWidth().background(Night).padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Neon), contentAlignment = Alignment.Center) {
            Text("SH", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("She&He", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, style = androidx.compose.ui.text.TextStyle(brush = Neon))
            Text(when(tab) { "خانه" -> "Connect · Share · Live"; "کیف پول" -> "خدمات مالی"; else -> tab }, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = Color.White) }
        IconButton(onClick = {}) { Icon(Icons.Default.Search, null, tint = Color.White) }
    }
}

@Composable fun HomeScreen(liked: Set<Int>, onLike: (Int) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { StoriesRow() }
        item { Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) { Text("برای تو", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.weight(1f)); Text("جدیدترین پست‌ها", color = Muted, fontSize = 12.sp) } }
        items(listOf(1,2,3)) { id -> PostCard(id, liked = id in liked, onLike = { onLike(id) }) }
    }
}

@Composable fun StoriesRow() {
    val names = listOf("داستان من", "سارا", "آرمان", "نیلوفر", "امیر", "رها")
    val colors = listOf(Color(0xFF7C3AED), Pink, Cyan, Color(0xFFFF9A5A), Color(0xFF34D399), Color(0xFF818CF8))
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) { Text("استوری‌ها", color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("مشاهده همه", color = Violet, fontSize = 12.sp) }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            names.forEachIndexed { i, name -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp)) {
                Box(Modifier.size(58.dp).border(2.dp, Brush.linearGradient(listOf(Pink, Violet, Cyan)), CircleShape).padding(4.dp).clip(CircleShape).background(Brush.linearGradient(listOf(colors[i], Panel2))), contentAlignment = Alignment.Center) {
                    if (i == 0) Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(25.dp)) else Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
                Spacer(Modifier.height(5.dp)); Text(name, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            } }
        }
    }
}

@Composable fun PostCard(id: Int, liked: Boolean, onLike: () -> Unit) {
    val name = when(id) { 1 -> "سارا محمدی"; 2 -> "آرمان رضایی"; else -> "نیلوفر" }
    val caption = when(id) { 1 -> "گاهی یک غروب ساده، تمام چیزی است که لازم داریم. ✨"; 2 -> "لحظه‌های کوچک، خاطره‌های بزرگ می‌سازند."; else -> "امروز را با انرژی خوب شروع کن 💜" }
    val paints = listOf(listOf(Color(0xFF512DA8), Color(0xFFEC4899)), listOf(Color(0xFF0E7490), Color(0xFF312E81)), listOf(Color(0xFFBE185D), Color(0xFFF59E0B)))
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(22.dp)).background(Panel)) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(paints[id-1])), contentAlignment = Alignment.Center) { Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text("${id+1} ساعت پیش · عمومی", color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.MoreHoriz, null, tint = Muted)
        }
        Box(Modifier.fillMaxWidth().height(230.dp).background(Brush.linearGradient(paints[id-1])), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color.White.copy(alpha=.18f), Color.Transparent))))
            Icon(when(id) { 1 -> Icons.Default.WbTwilight; 2 -> Icons.Default.Explore; else -> Icons.Default.AutoAwesome }, null, tint = Color.White.copy(alpha=.9f), modifier = Modifier.size(88.dp))
            Text("SHE&HE  •  MOMENTS", color = Color.White.copy(alpha=.75f), fontSize = 10.sp, letterSpacing = 3.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onLike) { Icon(if(liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if(liked) Pink else Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Default.ModeCommentOutline, null, tint = Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Default.Send, null, tint = Color.White) }
            Spacer(Modifier.weight(1f)); Icon(Icons.Default.BookmarkBorder, null, tint = Color.White, modifier = Modifier.padding(end = 8.dp))
        }
        Text(if(liked) "۱٬۲۴۱ پسند · از جمله تو" else "۱٬۲۴۰ پسند", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 15.dp))
        Text(caption, color = Color(0xFFE9E8F3), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 8.dp))
        Text("دیدن همه دیدگاه‌ها", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 15.dp, bottom = 14.dp))
    }
}

@Composable fun DiscoverScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("کشف چیزهای تازه", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("موضوع‌ها و آدم‌هایی که شاید دوست داشته باشی", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top=6.dp, bottom=16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("همه", "عکاسی", "سفر", "هنر").forEach { AssistChip(onClick = {}, label = { Text(it) }) } }
        val items = listOf("لحظه‌های سفر", "هنر و خلاقیت", "زندگی روزمره", "تکنولوژی", "غذا و آشپزی", "ورزش و سلامتی")
        items.forEachIndexed { i, title -> Row(Modifier.fillMaxWidth().padding(vertical=6.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(listOf(Pink, Violet), listOf(Cyan, Violet), listOf(Color(0xFFF59E0B), Pink))[i % 3])), contentAlignment=Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint=Color.White) }
            Column(Modifier.weight(1f).padding(start=12.dp)) { Text(title, color=Color.White, fontWeight=FontWeight.SemiBold); Text("پست‌های منتخب این بخش", color=Muted, fontSize=11.sp) }
            Icon(Icons.Default.ChevronRight, null, tint=Muted)
        } }
    }
}

@Composable fun MessagesScreen() {
    val names = listOf("سارا محمدی", "آرمان رضایی", "نیلوفر احمدی", "امیر حسینی", "رها کریمی", "گروه دوستان")
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        Text("پیام‌ها", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(vertical=12.dp))
        OutlinedTextField(value="", onValueChange={}, placeholder={ Text("جست‌وجوی گفتگو", color=Muted) }, leadingIcon={ Icon(Icons.Default.Search, null, tint=Muted) }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp), singleLine=true)
        Spacer(Modifier.height(12.dp))
        names.forEachIndexed { i, name -> Row(Modifier.fillMaxWidth().clickable{}.padding(vertical=10.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pink,Violet,Cyan))), contentAlignment=Alignment.Center) { Text(name.take(1), color=Color.White, fontWeight=FontWeight.Bold, fontSize=18.sp) }
            Column(Modifier.weight(1f).padding(start=12.dp)) { Text(name, color=Color.White, fontWeight=FontWeight.SemiBold); Text(listOf("عکس‌ها عالی بودن!", "بعداً باهات تماس می‌گیرم", "سلام، خوبی؟", "ممنون 🙌", "پیام جدید", "۶ پیام جدید")[i], color=Muted, fontSize=12.sp, maxLines=1) }
            Text(if(i%2==0) "۱۰:۴۲" else "دیروز", color=Muted, fontSize=10.sp)
        }; HorizontalDivider(color=Panel2) }
        Spacer(Modifier.height(10.dp)); Text("این صفحه در حال حاضر نمونهٔ رابط کاربری است؛ پیام‌رسانی آنلاین پس از اتصال سرور فعال می‌شود.", color=Muted, fontSize=11.sp)
    }
}

@Composable fun WalletScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("کیف پول و خدمات", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF7C3AED), Color(0xFFDB2777), Color(0xFF2563EB)))).padding(22.dp)) {
            Column { Text("موجودی نمایشی", color=Color.White.copy(alpha=.8f), fontSize=13.sp); Spacer(Modifier.height(8.dp)); Text("۰ تومان", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); Text("این موجودی واقعی نیست و تراکنشی انجام نمی‌دهد.", color=Color.White.copy(alpha=.8f), fontSize=11.sp) }
            Icon(Icons.Default.AccountBalanceWallet, null, tint=Color.White.copy(alpha=.28f), modifier=Modifier.size(74.dp).align(Alignment.CenterEnd))
        }
        Spacer(Modifier.height(20.dp)); Text("خدمات پرکاربرد", color=Color.White, fontWeight=FontWeight.Bold, fontSize=17.sp)
        val services = listOf(Triple("کارت‌به‌کارت", Icons.Default.SyncAlt, "انتقال از طریق سرویس مجاز"), Triple("خرید شارژ", Icons.Default.PhoneAndroid, "اپراتورهای ایرانی"), Triple("پرداخت قبض", Icons.Default.ReceiptLong, "آب، برق، گاز و تلفن"), Triple("تاریخچه", Icons.Default.History, "مشاهده تراکنش‌ها"))
        services.chunked(2).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.padding(top=12.dp)) { row.forEach { item -> Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Panel).clickable{}.padding(16.dp)) { Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Violet,Pink))), contentAlignment=Alignment.Center) { Icon(item.second, null, tint=Color.White) }; Spacer(Modifier.height(12.dp)); Text(item.first, color=Color.White, fontWeight=FontWeight.SemiBold, fontSize=13.sp); Text(item.third, color=Muted, fontSize=10.sp, modifier=Modifier.padding(top=4.dp)) } } } }
        Spacer(Modifier.height(16.dp)); Text("برای فعال‌سازی تراکنش واقعی، اتصال به ارائه‌دهندهٔ پرداخت مجاز و تأییدهای لازم ضروری است.", color=Muted, fontSize=11.sp)
    }
}

@Composable fun ProfileScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Box(Modifier.size(92.dp).border(3.dp, Neon, CircleShape).padding(5.dp).clip(CircleShape).background(Panel2), contentAlignment=Alignment.Center) { Text("SH", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Black, color=Color.White) }
        Spacer(Modifier.height(12.dp)); Text("کاربر She&He", color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold); Text("@your_username", color=Muted, fontSize=12.sp)
        Spacer(Modifier.height(20.dp)); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(vertical=18.dp), horizontalArrangement=Arrangement.SpaceEvenly) { Stat("۰", "پست"); Stat("۰", "دنبال‌کننده"); Stat("۰", "دنبال‌شونده") }
        Spacer(Modifier.height(16.dp)); Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=Violet), shape=RoundedCornerShape(14.dp), modifier=Modifier.fillMaxWidth()) { Text("ویرایش پروفایل") }
        Spacer(Modifier.height(16.dp)); listOf("پست‌های من", "ذخیره‌شده‌ها", "تنظیمات و حریم خصوصی", "راهنما و پشتیبانی").forEach { Row(Modifier.fillMaxWidth().padding(vertical=8.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.ChevronRight, null, tint=Violet); Text(it, color=Color.White, modifier=Modifier.padding(start=8.dp)); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ArrowForwardIos, null, tint=Muted, modifier=Modifier.size(14.dp)) } }
    }
}
@Composable fun Stat(number: String, label: String) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(number, color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold); Text(label, color=Muted, fontSize=11.sp) } }

@Composable fun BottomBar(selected: String, onSelect: (String)->Unit) {
    val tabs = listOf(Triple("خانه", Icons.Default.Home, "خانه"), Triple("کشف", Icons.Default.Explore, "کشف"), Triple("افزودن", Icons.Default.AddCircle, "افزودن"), Triple("پیام‌ها", Icons.Default.ChatBubbleOutline, "پیام‌ها"), Triple("کیف پول", Icons.Default.Wallet, "کیف پول"))
    NavigationBar(containerColor = Color(0xFF101020), contentColor = Color.White, tonalElevation = 0.dp) {
        tabs.forEach { (label, icon, key) -> NavigationBarItem(selected = selected == key, onClick = { onSelect(key) }, icon = { Icon(icon, null, modifier=if(key=="افزودن") Modifier.size(29.dp) else Modifier.size(23.dp), tint=if(selected==key || key=="افزودن") Pink else Muted) }, label = { Text(label, fontSize=9.sp, maxLines=1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor=Pink, selectedTextColor=Color.White, unselectedIconColor=Muted, unselectedTextColor=Muted, indicatorColor=Panel2)) }
        NavigationBarItem(selected = selected == "پروفایل", onClick = { onSelect("پروفایل") }, icon = { Icon(Icons.Default.PersonOutline, null, tint=if(selected=="پروفایل") Pink else Muted) }, label = { Text("پروفایل", fontSize=9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor=Pink, selectedTextColor=Color.White, unselectedIconColor=Muted, unselectedTextColor=Muted, indicatorColor=Panel2))
    }
}
@Composable fun TextButton2(label: String, onClick: () -> Unit) { TextButton(onClick=onClick) { Text(label, color=Color(0xFFC4B5FD)) } }
